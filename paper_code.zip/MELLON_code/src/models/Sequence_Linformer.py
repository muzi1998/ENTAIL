# coding=utf-8

import torch
import torch.nn.functional as F
from src.models.BaseModel import BaseModel
from src.utils import utils
import numpy as np
from src.utils import global_p
# -----------------------add----------------------------------
import torch.nn as nn
import math
from models.LinformerMHA import MHAttention, get_EF, gen_causal_mask
# ------------------------------------------------------------
class PointWiseFeedForward(torch.nn.Module):
    def __init__(self, hidden_units, dropout_rate):

        super(PointWiseFeedForward, self).__init__()

        self.conv1 = torch.nn.Conv1d(hidden_units, hidden_units, kernel_size=1)
        self.dropout1 = torch.nn.Dropout(p=dropout_rate)
        self.relu = torch.nn.ReLU()
        self.conv2 = torch.nn.Conv1d(hidden_units, hidden_units, kernel_size=1)
        self.dropout2 = torch.nn.Dropout(p=dropout_rate)

    def forward(self, inputs):
        outputs = self.dropout2(self.conv2(self.relu(self.dropout1(self.conv1(inputs.transpose(-1, -2))))))
        outputs = outputs.transpose(-1, -2) # as Conv1D requires (N, C, Length)
        outputs += inputs
        return outputs
class BiTransformer(nn.Module):
    def __init__(self, input_dim, dim_feedforward=16, dropout=0.1, num_layers=1):
        super(BiTransformer, self).__init__()
        # Transformer 编码层
        self.encoder_layer = nn.TransformerEncoderLayer(d_model=input_dim, nhead=4, dim_feedforward=dim_feedforward, dropout=dropout,activation='relu')
        self.encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=num_layers)
        self.layer_norm = nn.LayerNorm(input_dim)

    def forward(self, x):
        # 将输入转为 [sequence_length, batch_size, input_dim]
        x = x.permute(1, 0, 2)  # 转置
        # 对输入进行归一化
        x = self.layer_norm(x)
        return self.encoder(x).permute(1, 0, 2)

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len):
        """
        位置编码模块
        :param d_model: 特征维度
        :param max_len: 序列的最大长度
        """
        super(PositionalEncoding, self).__init__()
        # 初始化位置编码矩阵
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(1))  # [max_len, 1, d_model]

    def forward(self, x):
        """
        将位置编码添加到输入中
        :param x: 输入张量，形状 [sequence_length, batch_size, d_model]
        :return: 添加位置编码后的张量
        """
        # 将输入转为 [sequence_length, batch_size, input_dim]
        x = x.permute(1, 0, 2)  # 转置
        seq_len = x.size(0)
        return x + self.pe[:seq_len]

class NCR(BaseModel):
    append_id = True
    include_id = False
    include_user_features = False
    include_item_features = False

    @staticmethod
    def parse_model_args(parser, model_name='NCR'):
        parser.add_argument('--u_vector_size', type=int, default=64,
                            help='Size of user vectors.')
        parser.add_argument('--i_vector_size', type=int, default=64,
                            help='Size of item vectors.')
        parser.add_argument('--r_weight', type=float, default=10,
                            help='Weight of logic regularizer loss')
        parser.add_argument('--ppl_weight', type=float, default=0,
                            help='Weight of uv interaction prediction loss')
        parser.add_argument('--pos_weight', type=float, default=0,
                            help='Weight of positive purchase loss')
        return BaseModel.parse_model_args(parser, model_name)

    def __init__(self, label_min, label_max, feature_num, user_num, item_num, u_vector_size, i_vector_size,
                 r_weight, ppl_weight, pos_weight, random_seed, model_path, his_len):
        self.u_vector_size, self.i_vector_size = u_vector_size, i_vector_size
        assert self.u_vector_size == self.i_vector_size
        self.ui_vector_size = self.u_vector_size
        self.user_num = user_num
        self.item_num = item_num
        self.r_weight = r_weight
        self.ppl_weight = ppl_weight
        self.pos_weight = pos_weight
        self.sim_scale = 10
        # -----------------------------add--------------------------------
        self.his_len = his_len
        # ----------------------------------------------------------------
        BaseModel.__init__(self, label_min=label_min, label_max=label_max,
                           feature_num=feature_num, random_seed=random_seed,
                           model_path=model_path)

    def _init_weights(self):
        self.iid_embeddings = torch.nn.Embedding(self.item_num, self.ui_vector_size)
        self.uid_embeddings = torch.nn.Embedding(self.user_num, self.ui_vector_size)
        # ---------------------------------add---------------------------------------
        self.attn_drop = nn.Dropout(0.1)
        self.proj_dim_k = int(self.ui_vector_size/4)
        self.hidden_units = int(self.ui_vector_size)
        self.attention_layernorms = torch.nn.ModuleList().to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.attention_layers = torch.nn.ModuleList().to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.forward_layernorms = torch.nn.ModuleList().to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.forward_layers = torch.nn.ModuleList().to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.last_layernorm = torch.nn.LayerNorm(self.hidden_units, eps=1e-8).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.num_blocks = 2
        self.num_heads = 2
        self.dropout_rate = 0.1
        self.max_len = 10
        self.E_proj = get_EF(self.max_len, self.proj_dim_k, method="learnable")
        self.casual_mask = gen_causal_mask(self.max_len, self.proj_dim_k).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        for _ in range(self.num_blocks):
            new_attn_layernorm = torch.nn.LayerNorm(self.hidden_units, eps=1e-8).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            self.attention_layernorms.append(new_attn_layernorm)
            new_attn_layer = MHAttention(
                self.max_len,
                self.hidden_units,
                self.proj_dim_k,
                self.num_heads,
                self.dropout_rate,
                self.E_proj,
                self.E_proj,
                self.casual_mask
            ).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            self.attention_layers.append(new_attn_layer)
            new_fwd_layernorm = torch.nn.LayerNorm(self.hidden_units, eps=1e-8).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            self.forward_layernorms.append(new_fwd_layernorm)
            new_fwd_layer = PointWiseFeedForward(self.hidden_units, self.dropout_rate).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            self.forward_layers.append(new_fwd_layer)
        # ---------------------------------------------------------------------------
    # ---------------------------------add---------------------------------------
    # 定义聚合函数
    def aggregate_items(self, sequence, group_size):
        grouped_representation = []
        # print(sequence.shape)
        for i in range(0, sequence.shape[1], group_size):
            group = sequence[:, i:i + group_size]
            # attention_mask = ~torch.tril(torch.ones((max_len, max_len), dtype=torch.bool, device=self.dev))
            for i in range(len(self.attention_layers)):
                Q = self.attention_layernorms[i](group)
                mha_outputs = self.attention_layers[i](Q, group)  # Q & seqs: [batch_size, seq_len, hidden_size]
                group = Q + mha_outputs
                group = self.forward_layernorms[i](group)
                group = self.forward_layers[i](group)
            group = self.last_layernorm(group)
            group_mean = group.mean(dim=1)  # 求平均值
            grouped_representation.append(group_mean)
        output = torch.stack(grouped_representation, dim=1)

        return output
    # ---------------------------------------------------------------------------

    def predict(self, feed_dict):
        check_list = []
        u_ids = feed_dict['X'][:, 0].long()
        i_ids = feed_dict['X'][:, 1].long()
        history = feed_dict[global_p.C_HISTORY]
        # print(history.size())
        batch_size, his_length = list(history.size())

        # user/item vectors shape: (batch_size, embedding_size)
        user_vectors = self.uid_embeddings(u_ids)
        item_vectors = self.iid_embeddings(i_ids)

        # concat iids with uids and send to purchase gate to prepare for logic_and gate
        item_vectors = torch.cat((user_vectors, item_vectors), dim=1)
        item_vectors = self.purchase_gate(item_vectors)

        # expand user vector to prepare for concatenating with history item vectors
        uh_vectors = user_vectors.view(user_vectors.size(0), 1, user_vectors.size(1))
        # history item purchase hidden factors shape: (batch, user, embedding)
        his_vectors = self.iid_embeddings(history.long())

        # 添加位置编码
        his_vectors = self.positional_encoding(his_vectors).permute(1, 0, 2) # [batch_size, sequence_length, input_dim]

        if his_vectors.shape[1] > 10:
            # 1. Earlier部分: 0:-5，分为两组
            earlier_part = his_vectors[:, :-10]
            group_num = 10#math.ceil(earlier_part.shape[1]/3)
            earlier_representation = self.aggregate_items(earlier_part, group_num)
            # 2. Latest部分: 保留不变
            latest_part = his_vectors[:, -10:]
            # 拼接最终序列
            his_final_sequence = torch.cat([earlier_representation, latest_part], dim=1)
            his_len_new = his_final_sequence.shape[1]
        else:
            his_final_sequence = his_vectors
            his_len_new = his_vectors.shape[1]

        constraint = []
        tmp_vector = self.logic_not(his_final_sequence[:, 0])
        shuffled_history_idx = [i for i in range(1, his_len_new)]
        np.random.shuffle(shuffled_history_idx)
        for i in shuffled_history_idx:
            tmp_vector = self.logic_or(tmp_vector, self.logic_not(his_final_sequence[:, i]))
            constraint.append(tmp_vector.view(batch_size, -1, self.ui_vector_size))
        left_vector = tmp_vector
        # constraint.append(left_vector.view(batch_size, -1, self.ui_vector_size))

        right_vector = item_vectors
        constraint.append(right_vector.view(batch_size, -1, self.ui_vector_size))
        sent_vector = self.logic_or(left_vector, right_vector)
        constraint.append(sent_vector.view(batch_size, -1, self.ui_vector_size))
        # check_list.append(('sent_vector', sent_vector))
        if feed_dict['rank'] == 1:
            prediction = F.cosine_similarity(sent_vector, self.true.view([1, -1])) * 10
        else:
            prediction = F.cosine_similarity(sent_vector, self.true.view([1, -1])) * \
                         (self.label_max - self.label_min) / 2 + (self.label_max + self.label_min) / 2
        # check_list.append(('prediction', prediction))
        # prediction = (cf_u_vectors * cf_i_vectors).sum(dim=1).view([-1])
        constraint = torch.cat(constraint, dim=1)
        out_dict = {'prediction': prediction,
                    # 'predict_purchase': predict_purchase,
                    # 'his_vectors': his_vectors,
                    'check': check_list,
                    'constraint': constraint,
                    'interim': left_vector}
        return out_dict

    def forward(self, feed_dict):
        """
        除了预测之外，还计算loss
        :param feed_dict: 型输入，是个dict
        :return: 输出，是个dict，prediction是预测值，check是需要检查的中间结果，loss是损失
        """
        out_dict = self.predict(feed_dict)
        check_list = out_dict['check']
        # predict_purchase = out_dict['predict_purchase']
        false = self.logic_not(self.true).view(1, -1)
        # his_vectors = out_dict['his_vectors']
        constraint = out_dict['constraint']

        # regularizer
        dim = len(constraint.size())-1


        # check_list.append(('r_or_not_self', r_or_not_self))
        # check_list.append(('r_or_not_self_inverse', r_or_not_self_inverse))

        # True/False
        true_false = 1 + F.cosine_similarity(self.true, false.view(-1), dim=0)


        # pos_loss = None
        # recommendation loss
        if feed_dict['rank'] == 1:
            batch_size = int(feed_dict['Y'].shape[0] / 2)
            # tf_matrix = self.true.view(1, -1).expand(batch_size, -1)
            pos, neg = out_dict['prediction'][:batch_size], out_dict['prediction'][batch_size:]
            # pos_loss = 10 - torch.mean(pos)
            loss = -(pos - neg).sigmoid().log().sum()
            # check_list.append(('bpr_loss', loss))
        else:
            loss = torch.nn.MSELoss()(out_dict['prediction'], feed_dict['Y'])

        # predict_purchase_loss = (2 - predict_purchase)
        loss = loss #+ self.ppl_weight * predict_purchase_loss #+ self.pos_weight * pos_loss
        # check_list.append(('r_loss', r_loss))
        out_dict['loss'] = loss
        out_dict['check'] = check_list
        return out_dict
