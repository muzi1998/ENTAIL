# coding=utf-8

import torch
import torch.nn.functional as F
from models.BaseModel import BaseModel
from utils import utils
import numpy as np
from utils import global_p
import torch.nn as nn
import math
from models.LinformerMHA import MHAttention, get_EF, gen_causal_mask

class PointWiseFeedForward(torch.nn.Module):
    def __init__(self, hidden_units, dropout_rate):

        super(PointWiseFeedForward, self).__init__()

        self.conv1 = torch.nn.Conv1d(hidden_units, hidden_units, kernel_size=1)
        self.dropout1 = torch.nn.Dropout(p=dropout_rate)
        self.relu = torch.nn.ReLU()
        self.conv2 = torch.nn.Conv1d(hidden_units, hidden_units, kernel_size=1)
        self.dropout2 = torch.nn.Dropout(p=dropout_rate)

    def forward(self, inputs):
        outputs = self.dropout2(self.conv2(self.relu(self.dropout1(self.conv1(inputs.transpose(-1, -2))))))
        outputs = outputs.transpose(-1, -2) # as Conv1D requires (N, C, Length)
        outputs += inputs
        return outputs


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len):
        """
        位置编码模块
        :param d_model: 特征维度
        :param max_len: 序列的最大长度
        """
        super(PositionalEncoding, self).__init__()
        # 初始化位置编码矩阵
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(1))  # [max_len, 1, d_model]

    def forward(self, x):
        """
        将位置编码添加到输入中
        :param x: 输入张量，形状 [sequence_length, batch_size, d_model]
        :return: 添加位置编码后的张量
        """
        # 将输入转为 [sequence_length, batch_size, input_dim]
        x = x.permute(1, 0, 2)  # 转置
        seq_len = x.size(0)
        return x + self.pe[:seq_len]


class BPRLoss(nn.Module):
    """BPRLoss, based on Bayesian Personalized Ranking

    Args:
        - gamma(float): Small value to avoid division by zero

    Shape:
        - Pos_score: (N)
        - Neg_score: (N), same shape as the Pos_score
        - Output: scalar.

    Examples::

        >>> loss = BPRLoss()
        >>> pos_score = torch.randn(3, requires_grad=True)
        >>> neg_score = torch.randn(3, requires_grad=True)
        >>> output = loss(pos_score, neg_score)
        >>> output.backward()
    """

    def __init__(self, gamma=1e-10):
        super(BPRLoss, self).__init__()
        self.gamma = gamma

    def forward(self, pos_score, neg_score):
        loss = -torch.log(self.gamma + torch.sigmoid(pos_score - neg_score)).mean()
        return loss




class NCR(BaseModel):
    append_id = True
    include_id = False
    include_user_features = False
    include_item_features = False

    @staticmethod
    def parse_model_args(parser, model_name='NCR'):
        parser.add_argument('--u_vector_size', type=int, default=16,
                            help='Size of user vectors.')# 16 64
        parser.add_argument('--i_vector_size', type=int, default=16,
                            help='Size of item vectors.')# 16 64
        parser.add_argument('--r_weight', type=float, default=10,
                            help='Weight of logic regularizer loss')
        parser.add_argument('--ppl_weight', type=float, default=0,
                            help='Weight of uv interaction prediction loss')
        parser.add_argument('--pos_weight', type=float, default=0,
                            help='Weight of positive purchase loss')
        return BaseModel.parse_model_args(parser, model_name)

    def __init__(self, label_min, label_max, feature_num, user_num, item_num, u_vector_size, i_vector_size,
                 r_weight, ppl_weight, pos_weight, random_seed, model_path,number_interest, short_number_interest, max_his_len):
        self.u_vector_size, self.i_vector_size = u_vector_size, i_vector_size
        assert self.u_vector_size == self.i_vector_size
        self.ui_vector_size = self.u_vector_size
        self.user_num = user_num
        self.item_num = item_num
        self.r_weight = r_weight
        self.ppl_weight = ppl_weight
        self.pos_weight = pos_weight
        self.sim_scale = 10
        # -------------------MI_extract-------------------------
        self.K = number_interest #number of interest
        self.K_short = short_number_interest  # number of interest
        self.max_his_len = max_his_len #number of iteration
        self.logic_gamma = torch.tensor(0.)
        self.logic_weight = r_weight
        # ------------------------------------------------------
        BaseModel.__init__(self, label_min=label_min, label_max=label_max,
                           feature_num=feature_num, random_seed=random_seed,
                           model_path=model_path)

    def _init_weights(self):
        self.iid_embeddings = torch.nn.Embedding(self.item_num, self.ui_vector_size)
        self.uid_embeddings = torch.nn.Embedding(self.user_num, self.ui_vector_size)
        self.true = torch.nn.Parameter(utils.numpy_to_torch(
            np.random.uniform(0, 0.1, size=self.ui_vector_size).astype(np.float32)), requires_grad=False)
        self.not_layer_1 = torch.nn.Linear(self.ui_vector_size, self.ui_vector_size)
        self.not_layer_2 = torch.nn.Linear(self.ui_vector_size, self.ui_vector_size)
        self.and_layer_1 = torch.nn.Linear(2 * self.ui_vector_size, self.ui_vector_size)
        self.and_layer_2 = torch.nn.Linear(self.ui_vector_size, self.ui_vector_size)
        self.or_layer_1 = torch.nn.Linear(2 * self.ui_vector_size, self.ui_vector_size)
        self.or_layer_2 = torch.nn.Linear(self.ui_vector_size, self.ui_vector_size)
        self.purchase_layer_1 = torch.nn.Linear(2 * self.ui_vector_size, self.ui_vector_size)
        self.purchase_layer_2 = torch.nn.Linear(self.ui_vector_size, self.ui_vector_size)
        # -------------------MI_extract-------------------------
        # one S for all routing operations, first dim is for batch broadcasting
        S = torch.empty(self.ui_vector_size, self.ui_vector_size)
        torch.nn.init.normal_(S, mean=0.0, std=1.0)
        self.S = torch.nn.Parameter(S) # don't forget to make S as model parameter
        self.dense1 = torch.nn.Linear(self.ui_vector_size, 4 * self.ui_vector_size)
        self.dense2 = torch.nn.Linear(4 * self.ui_vector_size, self.ui_vector_size)
        self.dense3 = torch.nn.Linear(4 * self.ui_vector_size, self.K)
        self.dense3_short = torch.nn.Linear(4 * self.ui_vector_size, self.K_short)
        base_B = torch.nn.init.normal_(torch.empty(self.K, self.ui_vector_size), mean=0.0, std=1.0).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.base_B = torch.nn.Parameter(base_B)
        base_position_embedding = torch.empty(self.ui_vector_size, self.ui_vector_size)
        torch.nn.init.normal_(base_position_embedding, mean=0.0, std=1.0)
        self.base_position_embedding = torch.nn.Parameter(base_position_embedding)
        # ---------------------------------add---------------------------------------
        self.positional_encoding = PositionalEncoding(d_model=self.ui_vector_size, max_len=self.max_his_len)
        self.attn_drop = nn.Dropout(0.1)
        self.proj_dim_k = int(self.ui_vector_size/4)
        self.hidden_units = int(self.ui_vector_size)
        self.attention_layernorms = torch.nn.ModuleList().to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.attention_layers = torch.nn.ModuleList().to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.forward_layernorms = torch.nn.ModuleList().to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.forward_layers = torch.nn.ModuleList().to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.last_layernorm = torch.nn.LayerNorm(self.hidden_units, eps=1e-8).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.num_blocks = 2
        self.num_heads = 2
        self.dropout_rate = 0.1
        self.max_len = 70 # subsequence length
        self.E_proj = get_EF(self.max_len, self.proj_dim_k, method="learnable")
        self.casual_mask = gen_causal_mask(self.max_len, self.proj_dim_k).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        for _ in range(self.num_blocks):
            new_attn_layernorm = torch.nn.LayerNorm(self.hidden_units, eps=1e-8).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            self.attention_layernorms.append(new_attn_layernorm)
            new_attn_layer = MHAttention(
                self.max_len,
                self.hidden_units,
                self.proj_dim_k,
                self.num_heads,
                self.dropout_rate,
                self.E_proj,
                self.E_proj,
                self.casual_mask
            ).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            self.attention_layers.append(new_attn_layer)
            new_fwd_layernorm = torch.nn.LayerNorm(self.hidden_units, eps=1e-8).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            self.forward_layernorms.append(new_fwd_layernorm)
            new_fwd_layer = PointWiseFeedForward(self.hidden_units, self.dropout_rate).to(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
            self.forward_layers.append(new_fwd_layer)
        # ---------------------------------------------------------------------------

    # ---------------------------------add---------------------------------------
    # 定义聚合函数
    def aggregate_items(self, sequence, group_size):
        grouped_representation = []
        # print(sequence.shape)
        for i in range(0, sequence.shape[1], group_size):
            group = sequence[:, i:i + group_size]
            # attention_mask = ~torch.tril(torch.ones((max_len, max_len), dtype=torch.bool, device=self.dev))
            for i in range(len(self.attention_layers)):
                Q = self.attention_layernorms[i](group)
                mha_outputs = self.attention_layers[i](Q, group)  # Q & seqs: [batch_size, seq_len, hidden_size]
                group = Q + mha_outputs
                group = self.forward_layernorms[i](group)
                group = self.forward_layers[i](group)
            group = self.last_layernorm(group)
            group_mean = group.mean(dim=1)  # 求平均值
            grouped_representation.append(group_mean)
        output = torch.stack(grouped_representation, dim=1)

        return output


    def logic_not(self, vector):
        vector = F.relu(self.not_layer_1(vector))
        vector = self.not_layer_2(vector)
        return vector

    def logic_and(self, vector1, vector2):
        assert(len(vector1.size()) == len(vector2.size()))
        vector = torch.cat((vector1, vector2), dim=(len(vector1.size()) - 1))
        vector = F.relu(self.and_layer_1(vector))
        vector = self.and_layer_2(vector)
        return vector

    def logic_or(self, vector1, vector2):
        assert (len(vector1.size()) == len(vector2.size()))
        vector = torch.cat((vector1, vector2), dim=(len(vector1.size()) - 1))
        vector = F.relu(self.or_layer_1(vector))
        vector = self.or_layer_2(vector)
        return vector

    def purchase_gate(self, uv_vector):
        uv_vector = F.relu(self.purchase_layer_1(uv_vector))
        uv_vector = self.purchase_layer_2(uv_vector)
        return uv_vector

    # def logic_output(self, vector):
    def mse(self, vector1, vector2):
        return ((vector1 - vector2) ** 2).mean()

    def squash(self, caps, bs):
        n = torch.norm(caps, dim=2).view(bs, self.K, 1)
        nSquare = torch.pow(n, 2)

        return (nSquare / ((1 + nSquare) * n + 1e-9)) * caps

    def BetaE_MI_Self_Attentive_short(self, his, add_pos):
        mask = (his != 0).unsqueeze(1).tile(1, self.K_short, 1)
        drop = (torch.ones_like(mask) * -(1 << 31)).type(torch.float32)
        item_list_emb = self.iid_embeddings(his.long()) # (bs, L, D)
        # # ---------------------add--------------------------------------------
        # dropout = nn.Dropout(0.1)
        # batch_size, his_len, his_dim = his.shape
        # mask = torch.triu(torch.ones(self.K_short, his_len), diagonal=1).bool().unsqueeze(0).repeat(batch_size, 1, 1).to(
        #     torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        # item_list_emb = his
        # # --------------------------------------------------------------------
        position_embedding = torch.tile(self.base_position_embedding, (item_list_emb.size(0), 1, 1))
        position_emb = torch.matmul(item_list_emb, position_embedding)

        if add_pos:

            item_list_add_pos = item_list_emb + position_emb

        else:
            item_list_add_pos = item_list_emb

        item_hidden = torch.tanh(self.dense1(item_list_add_pos))
        item_att_w = self.dense3_short(item_hidden).permute(0, 2, 1)
        item_att_w = torch.where(mask, item_att_w, drop)
        item_att_w = F.softmax(item_att_w, dim=-1)
        interest_emb = torch.matmul(item_att_w, item_list_add_pos)
        return  interest_emb


    def BetaE_MI_Self_Attentive_long(self, his):
        item_list_add_pos = his
        item_hidden = torch.tanh(self.dense1(item_list_add_pos))
        item_att_w = self.dense3(item_hidden).permute(0, 2, 1)
        item_att_w = F.softmax(item_att_w, dim=-1)
        item_att_w = self.attn_drop(item_att_w)
        interest_emb = torch.matmul(item_att_w, item_list_add_pos)
        return interest_emb




    def predict(self, feed_dict):
        check_list = []
        u_ids = feed_dict['X'][:, 0].long()
        i_ids = feed_dict['X'][:, 1].long()

        feed_dict[global_p.C_HISTORY] = feed_dict[global_p.C_HISTORY][:, ~torch.any(feed_dict[global_p.C_HISTORY] == -1, dim=0)]
        feed_dict[global_p.C_HISTORY_POS_TAG] = feed_dict[global_p.C_HISTORY_POS_TAG][:, ~torch.any(feed_dict[global_p.C_HISTORY_POS_TAG] == -1, dim=0)]
        history = feed_dict[global_p.C_HISTORY]
        batch_size, his_length = list(history.size())


        history_pos_tag = feed_dict[global_p.C_HISTORY_POS_TAG].unsqueeze(2).float()

        # user/item vectors shape: (batch_size, embedding_size)
        user_vectors = self.uid_embeddings(u_ids)
        item_vectors = self.iid_embeddings(i_ids)

        # concat iids with uids and send to purchase gate to prepare for logic_and gate
        item_vectors = torch.cat((user_vectors, item_vectors), dim=1)
        item_vectors = self.purchase_gate(item_vectors)

        # expand user vector to prepare for concatenating with history item vectors
        uh_vectors = user_vectors.view(user_vectors.size(0), 1, user_vectors.size(1))
        uh_vectors = uh_vectors.expand(history_pos_tag.size(0), history_pos_tag.size(1), uh_vectors.size(2))

        # history item purchase hidden factors shape: (batch, user, embedding)
        his_vectors = self.iid_embeddings(history.long())

        # concatenate user embedding with history item embeddings
        his_vectors = torch.cat((uh_vectors, his_vectors), dim=2)#I(u,i_1),...,I(u,i_n)

        # True/False representation of user item interactions
        his_vectors = self.purchase_gate(his_vectors)
        not_his_vectors = self.logic_not(his_vectors)

        # not_not_his_vectors = self.logic_not((not_his_vectors))
        # sim_before_after = F.cosine_similarity(his_vectors, not_not_his_vectors, dim=-1)
        constraint = list([his_vectors])
        constraint.append(not_his_vectors)

        his_vectors = history_pos_tag * his_vectors + (1 - history_pos_tag) * not_his_vectors
        # ---------------------------------add---------------------------------------
        # 添加位置编码
        his_vectors = self.positional_encoding(his_vectors).permute(1, 0, 2) # [batch_size, sequence_length, input_dim]

        if his_length == 100:
            # 1. subsequence length = 70
            earlier_part = his_vectors[:, :-10]
            earlier_representation = self.aggregate_items(earlier_part, self.max_len)
            # 2. recent items
            latest_part = his_vectors[:, -10:]
            his_final_sequence = torch.cat([earlier_representation, latest_part], dim=1)

        caps_long = self.BetaE_MI_Self_Attentive_long(his_final_sequence)  # Self_Attentive
        caps_short = self.BetaE_MI_Self_Attentive_short(history.long()[:, -10:], 1)  # Self_Attentive
        caps = torch.cat((caps_long, caps_short), dim=1)
        constraint = list([caps])
        each_caps = self.logic_not(caps)
        # --------------------long multi-interest > long single interest--------------------------------------
        each_sent_vector = [self.logic_or(each_caps[:,0], item_vectors)]
        for ind in range(1,self.K):
            each_sent_vector.append(self.logic_or(each_caps[:,ind], item_vectors))
        each_sent_vector_long = torch.stack(each_sent_vector,dim=1)
        long_each_prediction = torch.mean(F.cosine_similarity(each_sent_vector_long, self.true.view([1, -1]), dim=-1),dim=1) * 10
        # -----------------------------------------------------------------------------------------
        # --------------------short multi-interest > short single interest  & multi-interest > single interest--------------------------------------
        short_each_sent_vector = [self.logic_or(each_caps[:,self.K], item_vectors)]
        for ind in range(1,self.K_short):
            each_sent_vector.append(self.logic_or(each_caps[:,ind + self.K], item_vectors))
            short_each_sent_vector.append(self.logic_or(each_caps[:,ind + self.K], item_vectors))
        all_each_sent_vector = torch.stack(each_sent_vector, dim=1)
        short_each_sent_vector = torch.stack(short_each_sent_vector,dim=1)
        all_each_prediction = torch.mean(F.cosine_similarity(all_each_sent_vector, self.true.view([1, -1]), dim=-1),
                                           dim=1) * 10
        short_each_prediction = torch.mean(F.cosine_similarity(short_each_sent_vector, self.true.view([1, -1]), dim=-1),dim=1) * 10
        # ------------------------------------------------------------------------------------------------------
        tmp_vector = self.logic_not(caps[:, 0])
        shuffled_caps_idx = [i for i in range(1, self.K)]
        np.random.shuffle(shuffled_caps_idx)
        for i in shuffled_caps_idx:
            tmp_vector = self.logic_or(tmp_vector, self.logic_not(caps[:, i]))
            constraint.append(tmp_vector.view(batch_size, -1, self.ui_vector_size))
        left_vector = tmp_vector
        right_vector = item_vectors
        constraint.append(right_vector.view(batch_size, -1, self.ui_vector_size))
        sent_vector = self.logic_or(left_vector, right_vector)
        constraint.append(sent_vector.view(batch_size, -1, self.ui_vector_size))
        # check_list.append(('sent_vector', sent_vector))
        if feed_dict['rank'] == 1:
            prediction = F.cosine_similarity(sent_vector, self.true.view([1, -1])) * 10
        else:
            prediction = F.cosine_similarity(sent_vector, self.true.view([1, -1])) * \
                         (self.label_max - self.label_min) / 2 + (self.label_max + self.label_min) / 2
        constraint = torch.cat(constraint, dim=1)
        out_dict = {'prediction': prediction,
                    'all_each_prediction': all_each_prediction,
                    'long_each_prediction': long_each_prediction,
                    'short_each_prediction': short_each_prediction,
                    'check': check_list,
                    'constraint': constraint,
                    'interim': left_vector,
                    'caps': caps,
                    'item': item_vectors
                    }
        return out_dict


    def forward(self, feed_dict):
        """
        除了预测之外，还计算loss
        :param feed_dict: 型输入，是个dict
        :return: 输出，是个dict，prediction是预测值，check是需要检查的中间结果，loss是损失
        """
        out_dict = self.predict(feed_dict)
        batch_size = int(feed_dict['Y'].shape[0] / 2)
        check_list = out_dict['check']
        false = self.logic_not(self.true).view(1, -1)
        constraint = out_dict['constraint']

        # regularizer
        dim = len(constraint.size())-1

        # length constraint
        # r_length = constraint.norm(dim=dim)()

        # not

        r_not_not_true = (1 - F.cosine_similarity(self.logic_not(self.logic_not(self.true)), self.true, dim=0)).sum()
        r_not_not_self = \
            (1 - F.cosine_similarity(self.logic_not(self.logic_not(constraint)), constraint, dim=dim)).mean()
        r_not_self = (1 + F.cosine_similarity(self.logic_not(constraint), constraint, dim=dim)).mean()

        r_not_self = (1 + F.cosine_similarity(self.logic_not(constraint), constraint, dim=dim)).mean()

        r_not_not_not = \
            (1 + F.cosine_similarity(self.logic_not(self.logic_not(constraint)), self.logic_not(constraint), dim=dim)).mean()

        # and
        r_and_true = (1 - F.cosine_similarity(
            self.logic_and(constraint, self.true.expand_as(constraint)), constraint, dim=dim)).mean()
        r_and_false = (1 - F.cosine_similarity(
            self.logic_and(constraint, false.expand_as(constraint)), false.expand_as(constraint), dim=dim)).mean()
        r_and_self = (1 - F.cosine_similarity(self.logic_and(constraint, constraint), constraint, dim=dim)).mean()

        # NEW ADDED REG NEED TO TEST
        r_and_not_self = (1 - F.cosine_similarity(
            self.logic_and(constraint, self.logic_not(constraint)), false.expand_as(constraint), dim=dim)).mean()
        r_and_not_self_inverse = (1 - F.cosine_similarity(
            self.logic_and(self.logic_not(constraint), constraint), false.expand_as(constraint), dim=dim)).mean()

        # or
        r_or_true = (1 - F.cosine_similarity(
            self.logic_or(constraint, self.true.expand_as(constraint)), self.true.expand_as(constraint), dim=dim))\
            .mean()
        r_or_false = (1 - F.cosine_similarity(
            self.logic_or(constraint, false.expand_as(constraint)), constraint, dim=dim)).mean()
        r_or_self = (1 - F.cosine_similarity(self.logic_or(constraint, constraint), constraint, dim=dim)).mean()

        r_or_not_self = (1 - F.cosine_similarity(
            self.logic_or(constraint, self.logic_not(constraint)), self.true.expand_as(constraint), dim=dim)).mean()
        r_or_not_self_inverse = (1 - F.cosine_similarity(
            self.logic_or(self.logic_not(constraint), constraint), self.true.expand_as(constraint), dim=dim)).mean()

        # True/False
        true_false = 1 + F.cosine_similarity(self.true, false.view(-1), dim=0)

        r_loss = r_not_not_true + r_not_not_self + r_not_self + \
                 r_and_true + r_and_false + r_and_self + r_and_not_self + r_and_not_self_inverse + \
                 r_or_true + r_or_false + r_or_self + true_false + r_or_not_self + r_or_not_self_inverse + r_not_not_not
        r_loss = r_loss * self.r_weight

        # pos_loss = None
        # recommendation loss
        if feed_dict['rank'] == 1:
            batch_size = int(feed_dict['Y'].shape[0] / 2)
            # tf_matrix = self.true.view(1, -1).expand(batch_size, -1)
            pos, neg = out_dict['prediction'][:batch_size], out_dict['prediction'][batch_size:]
            # pos_loss = 10 - torch.mean(pos)
            loss = -(pos - neg).sigmoid().log().sum()
            all_each_loss = -(out_dict['prediction'][:batch_size] - out_dict['all_each_prediction'][
                                                                :batch_size]).sigmoid().log().sum() * self.logic_weight  # multi-interest > single interest
            long_each_loss = -(out_dict['prediction'][:batch_size] - out_dict['long_each_prediction'][
                                                                      :batch_size]).sigmoid().log().sum() * self.logic_weight  # multi-interest > single interest
            short_each_loss = -(out_dict['prediction'][:batch_size] - out_dict['short_each_prediction'][
                                                                      :batch_size]).sigmoid().log().sum() * self.logic_weight  # multi-interest > single interest
            loss = loss + r_loss + all_each_loss + long_each_loss + short_each_loss  # + self.ppl_weight * predict_purchase_loss #+ self.pos_weight * pos_loss

        else:
            loss = torch.nn.MSELoss()(out_dict['prediction'], feed_dict['Y'])


        out_dict['loss'] = loss
        out_dict['check'] = check_list
        return out_dict





class Model_ComiRec_SA(nn.Module):
    def __init__(self, n_mid, embedding_dim, hidden_size, batch_size, num_interest, seq_len=256, add_pos=True):
        super(Model_ComiRec_SA, self).__init__()

        self.dim = embedding_dim
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.num_interest = num_interest
        self.seq_len = seq_len
        self.add_pos = add_pos

        # Item embedding placeholder
        self.item_his_eb = nn.Parameter(torch.randn(batch_size, seq_len, embedding_dim))
        self.item_eb = nn.Parameter(torch.randn(batch_size, embedding_dim))
        self.mask = nn.Parameter(torch.ones(batch_size, seq_len))

        if add_pos:
            self.position_embedding = nn.Parameter(torch.randn(1, seq_len, embedding_dim))

        self.dense1 = nn.Linear(embedding_dim, hidden_size * 4)
        self.dense2 = nn.Linear(hidden_size * 4, num_interest)

    def forward(self):
        item_list_emb = self.item_his_eb.view(-1, self.seq_len, self.dim)

        if self.add_pos:
            position_emb = self.position_embedding.expand(item_list_emb.size(0), -1, -1)
            item_list_add_pos = item_list_emb + position_emb
        else:
            item_list_add_pos = item_list_emb

        item_hidden = torch.tanh(self.dense1(item_list_add_pos))
        item_att_w = self.dense2(item_hidden).permute(0, 2, 1)

        atten_mask = self.mask.unsqueeze(1).expand(-1, self.num_interest, -1)
        paddings = torch.ones_like(atten_mask) * (-2 ** 32 + 1)

        item_att_w = torch.where(atten_mask == 0, paddings, item_att_w)
        item_att_w = F.softmax(item_att_w, dim=-1)

        interest_emb = torch.matmul(item_att_w, item_list_emb)

        self.user_eb = interest_emb

        atten = torch.matmul(self.user_eb, self.item_eb.view(-1, self.dim, 1)).view(item_list_emb.size(0),
                                                                                    self.num_interest)
        atten = F.softmax(atten.pow(1), dim=-1)

        readout_indices = torch.argmax(atten, dim=1) + torch.arange(item_list_emb.size(0)) * self.num_interest
        readout = self.user_eb.view(-1, self.dim)[readout_indices]

        return readout

    def build_sampled_softmax_loss(self, item_eb, readout):
        # Implement your sampled softmax loss calculation here
        pass
